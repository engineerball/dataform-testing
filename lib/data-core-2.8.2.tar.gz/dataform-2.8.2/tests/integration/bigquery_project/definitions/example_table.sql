${type("table")}
select * from ${ref("sample_data")}
