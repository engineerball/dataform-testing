module.exports = {
  allUsersEmailAddress: "allusers@dataform.co"
};
