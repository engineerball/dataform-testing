while (true) {}
