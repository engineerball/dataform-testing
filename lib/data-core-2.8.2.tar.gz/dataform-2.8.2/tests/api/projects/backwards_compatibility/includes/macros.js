module.exports = {
  foo: value => `foo_${value}`,
}
