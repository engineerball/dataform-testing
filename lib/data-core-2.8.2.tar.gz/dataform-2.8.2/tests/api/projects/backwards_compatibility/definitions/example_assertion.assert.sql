select 1 as value where false
