${type("table")}
select 1 as ${macros.foo("bar")}
