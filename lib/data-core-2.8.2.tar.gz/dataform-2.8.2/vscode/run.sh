code --extensionDevelopmentPath=$PWD/vscode $@
