## This extension is in Alpha

**To run this extension you will need the dataform cli installed globally: `npm i -g @dataform/cli`.**

Includes:

- Syntax highlighting for `.sqlx` files
- Realtime compilation of your project
- `cmd + click` on a `ref()` function to go to the file that it references
