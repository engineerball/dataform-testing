cd vscode
npm i
npx vsce package --out $@
