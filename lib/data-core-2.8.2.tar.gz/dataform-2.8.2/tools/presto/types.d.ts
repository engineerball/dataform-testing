declare module "presto-client";
