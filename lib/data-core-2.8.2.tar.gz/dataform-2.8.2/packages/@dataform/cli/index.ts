import { runCli } from "df/cli";
runCli();
