import { listenForCompileRequest } from "df/sandbox/vm/compile";
listenForCompileRequest();
